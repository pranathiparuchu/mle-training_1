To run the code follow the following steps
-Install git and conda in your system
-Clone the repository and initialize the git in the project folder
-Create the environment given in the file env.yml
-Activate the newly created environment using the following command conda activate mle-dev
-Type the following command to run the python file "nonstandardcode.py" using python nonstandardcode.py

# mle-training-1